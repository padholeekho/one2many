import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fnf',
  templateUrl: './fnf.component.html',
  styleUrls: ['./fnf.component.css']
})
export class FnfComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
