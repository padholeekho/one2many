export * from 'src/app/shared/header/header.component';
export * from 'src/app/shared/nav/nav.component';
export * from 'src/app/shared/footer/footer.component';
export * from 'src/app/shared/fnf/fnf.component';
export * from 'src/app/shared/moduleRoute/moduleRoute';