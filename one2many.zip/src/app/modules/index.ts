/* .......All Module Export Features...... */

export * from 'src/app/modules/home/home.module';
export * from 'src/app/modules/about/about.module';
export * from 'src/app/modules/contact/contact.module'