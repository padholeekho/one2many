/* ......All Cotact Components Export Features....... */

export * from './pages/contact/contact.component'